from flask import Flask, render_template, request
import pickle
import numpy as np
import pickle
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier


app = Flask(__name__)


@app.route('/', methods=['GET', 'POST'])
def index():
    return render_template('predictor_app.html')


def predictor(predict_list):
    to_predict = np.array(predict_list).reshape(1, 13)
    model = pickle.load(open('model.pkl', 'rb'))
    result = model.predict(to_predict)
    return result


@app.route('/result',methods=['GET', 'POST'])
def result():
    if request.method == 'POST':
        predict_list = request.form.to_dict()
        predict_list = list(predict_list.values())
        predict_list = list(map(float, predict_list))
        result = predictor(predict_list)
        prediction = int(result)
        return render_template("result.html", prediction=prediction)


@app.route('/user_correction', methods=['GET', 'POST'])
def user_correction():
    wine = pd.read_csv('https://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data',
                       names=["Class", "Alcohol", "Malic acid", "Ash", "Alcalinity of ash", "Magnesium",
                              "Total phenols", "Flavanoids", "Nonflavanoid phenols", "Proanthocyanins",
                              "Color intensity", "Hue", "OD280/OD315", "Proline"])

    # Set inputs and outputs for training and testing
    inputs = wine.drop('Class', axis=1)
    outputs = wine['Class']

    # Randomly select train and test inputs and outputs
    inputs_train, inputs_test, outputs_train, outputs_test = train_test_split(inputs, outputs)

    # Normalization for our data
    scaler = StandardScaler()
    scaler.fit(inputs_train)
    inputs_train = scaler.transform(inputs_train)
    inputs_test = scaler.transform(inputs_test)

    # Train the model with 3 hidden layer with 1000 max iterations
    wine_mlp = MLPClassifier(hidden_layer_sizes=(13, 13, 13), max_iter=1000)
    # Fit the train data to the model
    wine_mlp.fit(inputs_train, outputs_train)

    return render_template('correction.html')


if __name__ == '__main__':
    app.run()
