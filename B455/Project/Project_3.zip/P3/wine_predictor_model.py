import pickle
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import classification_report

# First read the data
wine = pd.read_csv('https://archive.ics.uci.edu/ml/machine-learning-databases/wine/wine.data',
                   names=["Class", "Alcohol", "Malic acid", "Ash", "Alcalinity of ash", "Magnesium",
                          "Total phenols","Flavanoids", "Nonflavanoid phenols", "Proanthocyanins",
                          "Color intensity","Hue", "OD280/OD315", "Proline"])

# Set inputs and outputs for training and testing
inputs = wine.drop('Class', axis=1)
outputs = wine['Class']

# Randomly select train and test inputs and outputs
inputs_train, inputs_test, outputs_train, outputs_test = train_test_split(inputs, outputs)

# Normalization for our data
scaler = StandardScaler()
scaler.fit(inputs_train)
inputs_train = scaler.transform(inputs_train)
inputs_test = scaler.transform(inputs_test)

# Train the model with 3 hidden layer with 1000 max iterations
wine_mlp = MLPClassifier(hidden_layer_sizes=(13, 13, 13), max_iter=1000)
# Fit the train data to the model
wine_mlp.fit(inputs_train, outputs_train)

# Predictions: use our trained mlp model test with test data
prediction = wine_mlp.predict(inputs_test)
# Check the accuracy of our prediction 1 accuracy
print(classification_report(outputs_test,prediction))

##pickle.dump(wine_mlp, open('model.pkl', 'wb'))

model = pickle.load(open('model.pkl','rb'))
a = [12.72,1.81,2.2,18.8,86,2.2,2.53,0.26,1.77,3.9,1.16,3.14,714]
an = np.array(a).reshape(1, 13)
print(an)
print(model.predict(an))

